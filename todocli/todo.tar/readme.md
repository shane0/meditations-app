# readme todocli

this is a minimal and portable form of todocli

## install

- add the aliases to your .bash_aliases file
- extract todocli.tar.gz in any project folder

```sh
# Extract a (compressed) archive into the target directory:
mkdir -p test/todocli && tar xf todo.tar.gz -C test/todocli/
```

add to ~/.bash_aliases`

```sh
# todocli app 
alias t='clear && ./todocli/todo.sh'
alias d='clear && t listpri a'
alias snooze='clear && t listpri'
alias done='clear && cat ./todocli/done.txt'
alias tedit='vim ./todocli/todo.txt'
alias tall='clear && find . -name "todo.txt" | xargs grep "+"'
alias tpri='clear && find . -name "todo.txt" | xargs grep "(A"'
alias tprib='clear && find . -name "todo.txt" | xargs grep "(B"'
alias tpric='clear && find . -name "todo.txt" | xargs grep "(C"'
alias thelp='clear && ./todocli/todo.sh shorthelp'
```

```sh
## Create a gzipped archive from a directory using relative paths:
tar czf todocli.tar.gz -C todocli/ .
```
